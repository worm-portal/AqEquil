# AqEquil

Python package for aqueous chemical speciation. Work in progress.